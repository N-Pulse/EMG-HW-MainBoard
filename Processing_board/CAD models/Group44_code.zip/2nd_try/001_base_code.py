#%% Snippet for left PC (Ctrl + Enter to run cell)
# import os
# os.chdir('c:\\tp_astro')

# %% Packages needed 
import tp_astro as tp
from miscmath import fit_circle

# %% Packages needed for plotting and data handling
import numpy as np
import matplotlib.pyplot as plt

# %% Initialize communication (run cell once is enough)
cam, pos = tp.tp_init()

#%% Go to origin
pos.goto_absolute(0,0)

 # %% Set speed
pos.set_speed(3000,3000)

## 2 Experimental part
# %% 2.2.2 Measure the actual length of each arm
# We measured several points in the XY plane with getCentroid from the camera
# and fitted a circle to the points using fit_circle from miscmath.


# Measures for arm alpha
xy = []
xy.append(cam.getCentroid())
print(xy)
pos.goto_absolute(0,0)
# %%
xy.append(cam.getCentroid())
print(xy)

pos.goto_absolute(90,0)
# %%
xy.append(cam.getCentroid())
print(xy)


pos.goto_absolute(180,0)
# %%
xy.append(cam.getCentroid())
print(xy)


pos.goto_absolute(270,0)
# %%
xy.append(cam.getCentroid())
print(xy)

#%% Save the points in a file
with open("coord_arm_alpha.txt","w") as f:
    for line in xy:
        f.write(f"{line}\n")


# %% Get the estimate circle and save it to the file

xyarr = np.array(xy)
cx,cy, rad = fit_circle(xyarr[:,0], xyarr[:,1])
print(cx, cy, rad)  #sauver ça dans le file aussi
with open("fitted_circle_alpha.txt","a") as f:
    f.write(f"{cx} {cy} {rad} \n")
# %% Reopen it for data handling
xy = []
with open("coord_arm_alpha.txt", 'r') as file:
        for line in file:
            # Remove parentheses and split by comma
            line = line.strip('()\n')
            x, y = map(float, line.split(','))
            xy.append((x, y))
#%%
with open('fitted_circle_alpha.txt', 'r') as file:
    # Read the entire line and split it into values
    data = file.read().split()
    # Convert string values to floats
    circle_val = [float(x) for x in data]

print("Circle center: ", circle_val[0:2])
print("Circle radius: ", circle_val[2])


# %% Plot the points and the fitted circle
xyarr = np.array(xy)
plt.figure(figsize=(10, 10))
plt.scatter(xyarr[:,0], xyarr[:,1], color='blue', label='Measured Points', marker='o')
circle=plt.Circle(circle_val[0:2], circle_val[2], color='r', fill=False, label='Fitted Circle')
plt.scatter(circle_val[0], circle_val[1], color='red', label='Circle Center', marker='*')
plt.gca().add_patch(circle)
plt.legend()
plt.title(r'Length of alpha arm determination: $l_\alpha + l_\beta = $' + str(circle_val[2])[:5] + ' mm')
plt.show()
plt.savefig('l_alpha_det.png')
#%%
# Measures for arm beta
# go back to origin
pos.goto_absolute(0,0)
#%% Using the same process as before, we measure the points in the XY plane with getCentroid from the camera
# and fit a circle to the points using fit_circle from miscmath.

xy2 = []
print(xy2)
pos.goto_absolute(0,0)
# %%
xy2.append(cam.getCentroid())
print(xy2)

pos.goto_absolute(0,90)
# %%
xy2.append(cam.getCentroid())
print(xy2)


pos.goto_absolute(0,180)
# %%
xy2.append(cam.getCentroid())
print(xy2)


pos.goto_absolute(0,270)
# %%
xy2.append(cam.getCentroid())
print(xy2)

#%%
xy2arr = np.array(xy2)
cx2,cy2, l_beta = fit_circle(xy2arr[:,0], xy2arr[:,1])
with open("measures2.txt","w") as f:
    for line in xy2:
        f.write(f"{line}\n")
    f.write(f"{cx2} {cy2} {l_beta} \n")


# %% Reopen it for data handling
# %% Reopen it for data handling
xy2 = []
with open("coord_arm_beta.txt", 'r') as file:
        for line in file:
            # Remove parentheses and split by comma
            line = line.strip('()\n')
            x, y = map(float, line.split(','))
            xy2.append((x, y))
#%%
with open('fitted_circle_beta.txt', 'r') as file:
    # Read the entire line and split it into values
    data = file.read().split()
    # Convert string values to floats
    circle_val2 = [float(x) for x in data]

print("Circle center: ", circle_val2[0:2])
print("Circle radius: ", circle_val2[2])

# %% Plot the points and the fitted circle
xy2arr = np.array(xy2)
plt.figure(figsize=(10, 10))
plt.scatter(xy2arr[:,0], xy2arr[:,1], color='blue', label='Measured Points', marker='o')
circle2=plt.Circle(circle_val2[0:2], circle_val2[2], color='r', fill=False, label='Fitted Circle')
plt.scatter(circle_val2[0], circle_val2[1], color='red', label='Circle Center', marker='*')
plt.gca().add_patch(circle2)
plt.legend()
plt.title(r'Length of alpha arm determination: $l_\beta = $' + str(circle_val2[2])[:5] + ' mm')
plt.show()
plt.savefig('l_beta_det.png')

# %%
# deduce lengths of both arms 
# from xy2 we directly get l_beta
# from xy1 we get l_beta + l_alpha

l_beta = circle_val2[2]
l_alpha = circle_val[2]-l_beta

print("l_alpha = ", l_alpha)
print("l_beta = ", l_beta)
# %% 2 Accuracy and precision measurement
# 2.3.3 Practical measurement
# Realisation of the core positioning measurement for such robot using the following position with 
# (alpha,beta) : (0,0), (0,180), & (100,0), (10,0) degrees

x_alpha1 = np.zeros(10)
y_alpha1 = np.zeros(10)
x_alpha2 = np.zeros(10)
y_alpha2 = np.zeros(10)
x_beta1 = np.zeros(10)
y_beta1 = np.zeros(10)
x_beta2 = np.zeros(10)
y_beta2 = np.zeros(10)

# %%
# measurements for beta precision

for i in range(10):
    # go to the first position
    pos.goto_absolute(0,0)
    # wait for the command to finish
    pos.wait_move()
    # store the measured values
    x_beta1[i],y_beta1[i] = cam.getCentroid()

    # go to the second position
    pos.goto_absolute(0,180)  
    # wait for the command to finish
    pos.wait_move()
    # store the measured values
    x_beta2[i],y_beta2[i] = cam.getCentroid()
# %%
# measurements for alpha precision
for i in range(10):
    # go to the first position
    pos.goto_absolute(100,0)
    # wait for the command to finish
    pos.wait_move()
    # store the measured values
    x_alpha1[i],y_alpha2[i] = cam.getCentroid()

    # go to the second position
    pos.goto_absolute(10,0)  
    # wait for the command to finish
    pos.wait_move()
    # store the measured values
    x_alpha2[i],y_alpha2[i] = cam.getCentroid()

# %%
with open("measures_precision_alpha.txt","w") as f:
    f.write(f"Alpha1 = 0 angle measurements for precision (beta fixed).\n x_alpha1 = \n")
    for line in x_alpha1:
        f.write(f"{line},\n")
    f.write(f"y_alpha1 = \n")
    for line in y_alpha1:
        f.write(f"{line},\n")

    f.write(f"Alpha2 = 180 angle measurements for precision (beta fixed).\n x_alpha2 = \n")
    for line in x_alpha2:
        f.write(f"{line},\n")
    f.write(f"y_alpha2 = \n")
    for line in y_alpha2:
        f.write(f"{line},\n")
    f.write(f"y_alpha2 = \n")
# %% Save in text file the measures for beta
with open("measures_precision_beta.txt","w") as f:
    f.write(f"Beta1 = 0 angle measurements for precision (alpha fixed).\n x_beta1 = \n")
    for line in x_beta1:
        f.write(f"{line},\n")
    f.write(f"y_beta1 = \n")
    for line in y_beta1:
        f.write(f"{line},\n")

    f.write(f"Beta2 = 180 angle measurements for precision (alpha fixed).\n x_beta2 = \n")
    for line in x_beta2:
        f.write(f"{line},\n")
    f.write(f"y_beta2 = \n")
    for line in y_beta2:
        f.write(f"{line},\n")



# %% Alpha data extraction
alpha1_coords = []
alpha2_coords = []

current_array = None

with open('measures_precision_alpha_MODIF.txt', 'r') as file:
    for line in file:
        line = line.strip()
        
        if "Alpha1 =" in line:
            current_array = "alpha1"
            continue
        elif "Alpha2 =" in line:
            current_array = "alpha2"
            continue
        
        if line.startswith('[') and ',' in line:
            # Remove brackets and any trailing comma
            coord_str = line.strip('[],')
            # Split into x and y values and convert to float
            x, y = map(float, coord_str.split(','))
            
            if current_array == "alpha1":
                alpha1_coords.append([x, y])
            elif current_array == "alpha2":
                alpha2_coords.append([x, y])

#%% Beta data extraction
beta1_coords = []
beta2_coords = []

current_array = None

with open('measures_precision_beta_MODIF.txt', 'r') as file:
    for line in file:
        line = line.strip()
        
        if "Beta1 =" in line:
            current_array = "beta1"
            continue
        elif "Beta2 =" in line:
            current_array = "beta2"
            continue
        
        if line.startswith('[') and ',' in line:
            # Remove brackets and any trailing comma
            coord_str = line.strip('[],')
            # Split into x and y values and convert to float
            x, y = map(float, coord_str.split(','))
            
            if current_array == "beta1":
                beta1_coords.append([x, y])
            elif current_array == "beta2":
                beta2_coords.append([x, y])

# Convert to numpy arrays
alpha1 = np.array(alpha1_coords)
alpha2 = np.array(alpha2_coords)
beta1 = np.array(beta1_coords)
beta2 = np.array(beta2_coords)

x_alpha1 = alpha1[:, 0]
y_alpha1 = alpha1[:, 1]
x_alpha2 = alpha2[:, 0]
y_alpha2 = alpha2[:, 1]
x_beta1 = beta1[:, 0]
y_beta1 = beta1[:, 1]
x_beta2 = beta2[:, 0]
y_beta2 = beta2[:, 1]
# # Display the arrays
# print("Alpha1 (shape: {}):".format(alpha1.shape))
# print(alpha1)
# print("\nAlpha2 (shape: {}):".format(alpha2.shape))
# print(alpha2)
# print("\nBeta1 (shape: {}):".format(beta1.shape))
# print(beta1)
# print("\nBeta2 (shape: {}):".format(beta2.shape))
# print(beta2)

# %% Calculate the mean and standard deviation for each arm

# Calculate the mean for alpha 1
x_alpha1_mean = np.mean(x_alpha1)
y_alpha1_mean = np.mean(y_alpha1)
x_alpha1_std = np.std(x_alpha1)
y_alpha1_std = np.std(y_alpha1)


# Calculate the mean for alpha 2
x_alpha2_mean = np.mean(x_alpha2)
y_alpha2_mean = np.mean(y_alpha2)
x_alpha2_std = np.std(x_alpha2)
y_alpha2_std = np.std(y_alpha2)

# Calculate the mean for beta 1
x_beta1_mean = np.mean(x_beta1)
y_beta1_mean = np.mean(y_beta1)
x_beta1_std = np.std(x_beta1)
y_beta1_std = np.std(y_beta1)

# Calculate the mean for beta 2
x_beta2_mean = np.mean(x_beta2)
y_beta2_mean = np.mean(y_beta2)
x_beta2_std = np.std(x_beta2)
y_beta2_std = np.std(y_beta2)

# %% Plot the results as a scatter plot for alpha1 and alpha2
plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
plt.scatter(x_alpha1[:],y_alpha1[:], color='blue', label='Alpha1 (100 degrees)')
plt.scatter(x_alpha2[:],y_alpha2[:], color='red', label='Alpha2 (10 degrees)')

plt.title('Accuracy and precision measurements for Alpha Arm') 
plt.xlabel('X Position (mm)')
plt.ylabel('Y Position (mm)')
plt.legend()
plt.grid()
plt.axis('equal')
plt.show()
plt.savefig('alpha_arm_measurements.png')

# %%
# Plot the results as a scatter plot for alpha1 only
plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
plt.scatter(x_alpha1,y_alpha1, color='blue', label='Alpha1 (0 degrees)')
plt.scatter(x_alpha1_mean, y_alpha1_mean, color='green',marker='*', label='Mean Alpha1')
# plot the standard deviation as error bars
plt.errorbar(x_alpha1_mean, y_alpha1_mean, xerr=x_alpha1_std, yerr=y_alpha1_std, fmt='*', color='green', label='Alpha1 Std Dev')

plt.title('Accuracy and precision measurements for Alpha Arm') 
plt.xlabel('X Position (mm)')
plt.ylabel('Y Position (mm)')
plt.legend()
plt.grid()
plt.axis('equal')
plt.show()
plt.savefig('alpha1_arm_measurements.png')

# %% Plot the results as a scatter plot for alpha2 only
plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
plt.scatter(x_alpha2,y_alpha2, color='red', label='Alpha2 (180 degrees)')
plt.scatter(x_alpha2_mean, y_alpha2_mean, color='orange',marker='*', label='Mean Alpha2')

# plot the standard deviation as error bars
plt.errorbar(x_alpha2_mean, y_alpha2_mean, xerr=x_alpha2_std, yerr=y_alpha2_std, fmt='*', color='orange', label='Alpha2 Std Dev')

plt.title('Accuracy and precision measurements for Alpha arm (180 degrees)')
plt.xlabel('X Position (mm)')
plt.ylabel('Y Position (mm)')
plt.legend()
plt.grid()
plt.axis('equal')
plt.show()
plt.savefig('alpha2_arm_measurements.png')
# %% Plot the results as a scatter plot for beta1 and beta2
plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 2)
plt.scatter(x_beta1,y_beta1, color='blue', label='Beta1 (0 degrees)')
plt.scatter(x_beta2,y_beta2, color='red', label='Beta2 (180 degrees)')

plt.title('Accuracy and precision measurements for Beta Arm')
plt.xlabel('X Position (mm)')
plt.ylabel('Y Position (mm)')
plt.legend()
plt.grid()
plt.axis('equal')
plt.show()
plt.savefig('beta_arm_measurements.png')

# %% Plot the results as a scatter plot for beta1 only
plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 2)
plt.scatter(x_beta1,y_beta1, color='blue', label='Beta1 (0 degrees)')
plt.scatter(x_beta1_mean, y_beta1_mean, color='green',marker='*', label='Mean Beta1')

# plot the standard deviation as error bars
plt.errorbar(x_beta1_mean, y_beta1_mean, xerr=x_beta1_std, yerr=y_beta1_std, fmt='*', color='green', label='Beta1 Std Dev')
plt.title('Accuracy and precision measurements for Beta Arm (0 degrees)')
plt.xlabel('X Position (mm)')
plt.ylabel('Y Position (mm)')
plt.legend()
plt.grid()
plt.axis('equal')
plt.show()
plt.savefig('beta1_arm_measurements.png')

# %% Plot the results as a scatter plot for beta2 only
plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 2)
plt.scatter(x_beta2,y_beta2, color='red', label='Beta2 (180 degrees)')
plt.scatter(x_beta2_mean, y_beta2_mean, color='orange',marker='*', label='Mean Beta2')

# plot the standard deviation as error bars
plt.errorbar(x_beta2_mean, y_beta2_mean, xerr=x_beta2_std, yerr=y_beta2_std, fmt='*', color='orange', label='Beta2 Std Dev')
plt.title('Accuracy and precision measurements for Beta arm (180 degrees)')
plt.xlabel('X Position (mm)')
plt.ylabel('Y Position (mm)')
plt.legend()
plt.grid()
plt.axis('equal')
plt.show()
plt.savefig('beta2_arm_measurements')


# %% Save standard deviation plots in one single figure
plt.figure(figsize=(15, 10))

# Alpha1 plot
plt.subplot(2, 2, 1)
plt.scatter(x_alpha1, y_alpha1, color='blue', label='Alpha1 (0 degrees)')
plt.scatter(x_alpha1_mean, y_alpha1_mean, color='green', marker='*', label='Mean Alpha1')
plt.errorbar(x_alpha1_mean, y_alpha1_mean, xerr=x_alpha1_std, yerr=y_alpha1_std, fmt='*', color='green', label='Alpha1 Std Dev')
plt.title('Alpha Arm (0 degrees)')
plt.xlabel('X Position (mm)')
plt.ylabel('Y Position (mm)')
plt.legend()
plt.grid()
plt.axis('equal')

# Alpha2 plot
plt.subplot(2, 2, 2)
plt.scatter(x_alpha2, y_alpha2, color='red', label='Alpha2 (180 degrees)')
plt.scatter(x_alpha2_mean, y_alpha2_mean, color='orange', marker='*', label='Mean Alpha2')
plt.errorbar(x_alpha2_mean, y_alpha2_mean, xerr=x_alpha2_std, yerr=y_alpha2_std, fmt='*', color='orange', label='Alpha2 Std Dev')
plt.title('Alpha Arm (180 degrees)')
plt.xlabel('X Position (mm)')
plt.ylabel('Y Position (mm)')
plt.legend()
plt.grid()
plt.axis('equal')

# Beta1 plot
plt.subplot(2, 2, 3)
plt.scatter(x_beta1, y_beta1, color='blue', label='Beta1 (0 degrees)')
plt.scatter(x_beta1_mean, y_beta1_mean, color='green', marker='*', label='Mean Beta1')
plt.errorbar(x_beta1_mean, y_beta1_mean, xerr=x_beta1_std, yerr=y_beta1_std, fmt='*', color='green', label='Beta1 Std Dev')
plt.title('Beta Arm (0 degrees)')
plt.xlabel('X Position (mm)')
plt.ylabel('Y Position (mm)')
plt.legend()
plt.grid()
plt.axis('equal')

# Beta2 plot
plt.subplot(2, 2, 4)
plt.scatter(x_beta2, y_beta2, color='red', label='Beta2 (180 degrees)')
plt.scatter(x_beta2_mean, y_beta2_mean, color='orange', marker='*', label='Mean Beta2')
plt.errorbar(x_beta2_mean, y_beta2_mean, xerr=x_beta2_std, yerr=y_beta2_std, fmt='*', color='orange', label='Beta2 Std Dev')
plt.title('Beta Arm (180 degrees)')
plt.xlabel('X Position (mm)')
plt.ylabel('Y Position (mm)')
plt.legend()
plt.grid()
plt.axis('equal')

plt.tight_layout()
plt.savefig('all_measurements_with_std.png')
plt.show()

# %% Comment on the results
# The results show that the precision of the measurements is quite good, with small standard deviations for both arms.
# The accuracy of the measurements is also good, with the means being close to the expected values.
# The standard deviations indicate that the measurements are consistent and repeatable.
# The precision of the measurements is better for the alpha arm than for the beta arm, which is expected due to the design of the robot.
# The alpha arm is more rigid and less prone to flexing, while the beta arm is more flexible and can introduce more variability in the measurements.

# %% Print mean and standard deviation values
print("Alpha arm 1 mean: ", x_alpha1_mean, y_alpha1_mean)
print("Alpha arm 1 std: ", x_alpha1_std, y_alpha1_std)
print("Alpha arm 2 mean: ", x_alpha2_mean, y_alpha2_mean)
print("Alpha arm 2 std: ", x_alpha2_std, y_alpha2_std)

print("Beta arm 1 mean: ", x_beta1_mean, y_beta1_mean)
print("Beta arm 1 std: ", x_beta1_std, y_beta1_std)
print("Beta arm 2 mean: ", x_beta2_mean, y_beta2_mean)
print("Beta arm 2 std: ", x_beta2_std, y_beta2_std)


# %% Part 3 Backlash measurement

bl_alpha_x_cc = [109.85337628721197, 109.85398317805358, 109.8539619512775, 
                 109.85354906064502, 109.85385482145733, 109.85425275227765, 
                 109.8543240602928, 109.8546015025616, 109.85442581912157, 
                 109.85441693135401] # x coordinate measurement for backlash, counter-clockwise (beta fixed).
bl_alpha_x_c = [109.85482981187302, 109.85474862094601, 109.8545676885623, 
                109.85485520743062, 109.85503697780578, 109.85523325368503, 
                109.85497480314527, 109.85535168684319, 109.85524529503321, 
                109.85548111141628] # x coordinate measurement for backlash, clock (beta fixed).
bl_alpha_y_cc = [78.25004362011843, 78.25086044051095, 78.25077755526347, 
                 78.25073233480525, 78.25058532264966, 78.25124456159361, 
                 78.2511207300344, 78.2512491052862, 78.25113837412248, 
                 78.25149194992085] # y coordinate measurement for backlash, counter-clockwise (beta fixed).
bl_alpha_y_c = [78.25011606315971, 78.24999642389591, 78.25017733111537, 
                78.24979405770662, 78.25019103145381, 78.25039408506682, 
                78.25020965964892, 78.25042521271288, 78.25054075176206, 
                78.25086878580066] # y coordinate measurement for backlash, clock (beta fixed).

mean_alpha_x_cc = np.mean(bl_alpha_x_cc)
mean_alpha_x_c = np.mean(bl_alpha_x_c)
mean_alpha_y_cc = np.mean(bl_alpha_y_cc)
mean_alpha_y_c = np.mean(bl_alpha_y_c)

# Create the plot
plt.figure(figsize=(5,4))

# Plot points for alpha and alpha2
plt.plot(bl_alpha_x_cc,bl_alpha_y_cc, ".b",label="Counter-clockwise")
plt.plot(bl_alpha_x_c,bl_alpha_y_c, ".r",label="Clockwise")
plt.plot(mean_alpha_x_cc,mean_alpha_y_cc,"xb",markersize=10)
plt.plot(mean_alpha_x_c,mean_alpha_y_c,"xr",markersize=10)

# plt.xticks([])
# print actual value of x tick, not times 10^2
from matplotlib.ticker import ScalarFormatter

plt.xticks(np.arange(109.853, 109.86, 0.0005)) 
plt.gca().xaxis.set_major_formatter(ScalarFormatter(useOffset=False))
plt.xlabel("X",)
plt.ylabel("Y")
plt.legend()
plt.title(r"Backlash visualisation $\alpha$, counter- vs clockwise")
plt.axis("equal")
plt.show()
plt.savefig('Backlash_alpha.png')
# %%

bl_beta_x_cc = [104.69824645535526, 104.69777519703804, 104.6981218396148, 
                104.69803399062889, 104.69795754519767, 104.69840738604852, 
                104.69886677599013, 104.69879708169319, 104.69880813000034, 
                104.69914866358017] # x coordinate measurement for backlash, counter-clockwise (alpha fixed).
bl_beta_x_c = [104.7119733967104, 104.7108132871808, 104.71139285704697, 
               104.71115263790097, 104.7109111008516, 104.71102431567172, 
               104.71073891244437, 104.71093513616806, 104.71098296785175, 
               104.71078910248245] # x coordinate measurement for backlash, clock (alpha fixed).
bl_beta_y_cc = [80.53207886676239, 80.53226974680739, 80.53273695304945, 
                80.5328307918518, 80.53292086334947, 80.53335133592056, 
                80.53313099884382, 80.53340359234656, 80.53353714196379, 
                80.5336084741812] # y coordinate measurement for backlash, counter-clockwise (alpha fixed).
bl_beta_y_c = [80.53415572441544, 80.53469587085175, 80.53491464880288, 
               80.53468782663396, 80.53529590278141, 80.53531846138104, 
               80.53570022495381, 80.53604728919645, 80.5360267165471, 
               80.53611537698349] # y coordinate measurement for backlash, clock (alpha fixed).

mean_beta_x_cc = np.mean(bl_beta_x_cc)
mean_beta_x_c = np.mean(bl_beta_x_c)
mean_beta_y_cc = np.mean(bl_beta_y_cc)
mean_beta_y_c = np.mean(bl_beta_y_c)

# Create the plot
plt.figure(figsize=(5,3))

# Plot points for alpha and alpha2
plt.plot(bl_beta_x_cc,bl_beta_y_cc, ".b",label="Counter-clockwise")
plt.plot(bl_beta_x_c,bl_beta_y_c, ".r",label="Clockwise")
plt.plot(mean_beta_x_cc,mean_beta_y_cc,"xb",markersize=10)
plt.plot(mean_beta_x_c,mean_beta_y_c,"xr",markersize=10)

plt.xticks(rotation=45)
plt.xlabel("X",)
plt.ylabel("Y")
plt.legend()
plt.title(r"Backlash visualisation $\beta$, counter- vs clockwise")
plt.axis("equal")
plt.show()
plt.savefig('Backlash_beta.png')
# %%

print("Mean alpha x cc: ",mean_alpha_x_cc)
print("Mean alpha x c: ",mean_alpha_x_c)
print("Mean alpha y cc: ",mean_alpha_y_cc)
print("Mean alpha y c: ",mean_alpha_y_c)

print("Mean beta x cc: ",mean_beta_x_cc)
print("Mean beta x c: ",mean_beta_x_c)
print("Mean beta y cc: ",mean_beta_y_cc)
print("Mean beta y c: ",mean_beta_y_c)


# %%
