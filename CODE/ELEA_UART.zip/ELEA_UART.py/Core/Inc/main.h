/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32wbaxx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define GPIO_IN_Pin GPIO_PIN_7
#define GPIO_IN_GPIO_Port GPIOA
#define NC2_Pin GPIO_PIN_6
#define NC2_GPIO_Port GPIOA
#define GPIO_OUT_Pin GPIO_PIN_5
#define GPIO_OUT_GPIO_Port GPIOA
#define NC1_Pin GPIO_PIN_2
#define NC1_GPIO_Port GPIOA
#define NC0_Pin GPIO_PIN_1
#define NC0_GPIO_Port GPIOA
#define NC11_Pin GPIO_PIN_15
#define NC11_GPIO_Port GPIOC
#define NC10_Pin GPIO_PIN_14
#define NC10_GPIO_Port GPIOC
#define SPI3_NCS_Pin GPIO_PIN_13
#define SPI3_NCS_GPIO_Port GPIOC
#define LED_Pin GPIO_PIN_7
#define LED_GPIO_Port GPIOB
#define NC9_Pin GPIO_PIN_6
#define NC9_GPIO_Port GPIOB
#define NC8_Pin GPIO_PIN_5
#define NC8_GPIO_Port GPIOB
#define NC7_Pin GPIO_PIN_15
#define NC7_GPIO_Port GPIOA
#define ANT_LOGIC_2_Pin GPIO_PIN_12
#define ANT_LOGIC_2_GPIO_Port GPIOA
#define ANT_LOGIC_1_Pin GPIO_PIN_11
#define ANT_LOGIC_1_GPIO_Port GPIOA
#define NC6_Pin GPIO_PIN_2
#define NC6_GPIO_Port GPIOB
#define NC5_Pin GPIO_PIN_1
#define NC5_GPIO_Port GPIOB
#define NC4_Pin GPIO_PIN_15
#define NC4_GPIO_Port GPIOB
#define NC3_Pin GPIO_PIN_10
#define NC3_GPIO_Port GPIOA
#define ADC_GPIO3_Pin GPIO_PIN_9
#define ADC_GPIO3_GPIO_Port GPIOA
#define ADC_GPIO2_Pin GPIO_PIN_14
#define ADC_GPIO2_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
